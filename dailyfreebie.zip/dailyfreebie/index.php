<?
header("Location: https://add4a2letseam7s5lvu3dmsc1k.hop.clickbank.net/?tid=DAILYDEAL");
?>